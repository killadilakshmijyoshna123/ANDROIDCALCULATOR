# AndroidCalculator
> Ứng dụng Calculator - Báo cáo môn học Lập trình trên thiết bị di động

## Cài đặt

![Main Screen](screenshot-gif.gif?raw=true "Main Screen")

## Lưu ý

- Một số tính năng hiện không khả dụng - chỉ có Front-end chứ chưa có Back-end

## Hướng dẫn sử dụng

## Yêu cầu

## Các phiên bản

## Tác giả

Nếu có góp ý cho ứng dụng này, hoặc muốn sử dụng lại, vui lòng liên hệ qua email sau:
La Quốc Thắng - quocthang_0507@yahoo.com.vn